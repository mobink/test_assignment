# Infijoy_assignment

Both the classes are under src/test/java

# Assignment 1 - API

Classname - ValidateAPI

Part - 1- To sort the lastUpdated in Descending order

The main implementation is in sortDescendingOrder()

Part 2 - To check the NULL values
The main implementation is in validateNullCheck()

Both Can be executed from validateAPIResponse() Method.
It has TestNG annotation , we just needed to right click -> Run validateAPIResponse()

Output can be seen in console window


# Assignment 2 - UI
Pre-req
Chrome Driver 110 is placed in the root folder ,

I have placed both MAC OS and Windows compatible driver.


ClassName - ValidateAboutUsPage

Run the validateAboutUSPage() method as a TestNG test method,

we just needed to right click -> Run validateAboutUSPage()



